from __future__ import annotations
from pathlib import Path
from datetime import date, timedelta
import importlib
import sys
from random import Random
from time import time_ns
from duckdb import df
import pandas as pd
from typing import Any
from nicegui import ui

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from webapp import NiceGUI_grid_market_tb
importlib.reload(NiceGUI_grid_market_tb)
from webapp.NiceGUI_grid import create_market_grid
from DuckDB.Data import view_to_dataframe
from Ults.DuckLib import DuckDBManager
import Chart.plot as chart_plot
importlib.reload(chart_plot)
from Ults.lstPara import CHART_START_DATE, IFRAME_HEIGHT, THEME, TIMEFRAME_OPTIONS


CASHFLOW_UI_BUILD = "cashflow-tooltip-v3-20260801"
print(f"[CherryStock] Loaded {CASHFLOW_UI_BUILD} from {Path(__file__).resolve()}")
# =============================================================================
# Datagrid
# =============================================================================

def create_aggrid(df: pd.DataFrame) -> dict:
    row_data = (
        df.astype(object)
        .where(pd.notnull(df), None)
        .to_dict("records")
    )

    column_defs = []

    for col in df.columns:
        col_def = {
            "headerName": col.replace("_", " ").title(),
            "field": col,
            "sortable": True,
            "filter": True,
            "resizable": True,
            "floatingFilter": True,
        }
        # col_def.update(COLUMN_CONFIG.get(col, {}))
        # column_defs.append(col_def)

        # Numeric column
        if pd.api.types.is_numeric_dtype(df[col]):
            col_def["filter"] = "agNumberColumnFilter"
            col_def["width"] = 100

        # String column
        else:
            col_def["minWidth"] = 120
            col_def["flex"] = 1

        column_defs.append(col_def)

    options = {
        "columnDefs": column_defs,
        "rowData": row_data,
        "pagination": True,
        "paginationPageSize": 20,
    }

    return options

# =============================================================================
# Theme
# =============================================================================


rng = Random(2026)

# =============================================================================
# Mock data
# Replace these functions with DuckDB/Pandas queries in a real application.
# =============================================================================

def generate_ohlcv(days: int = 120, start_price: float = 100.0) -> list[dict[str, Any]]:
    """Generate deterministic OHLCV data for the demo."""
    start_date = date.today() - timedelta(days=days)
    price = start_price
    records: list[dict[str, Any]] = []

    for day_index in range(days):
        session_date = start_date + timedelta(days=day_index)
        open_price = price
        close_price = max(10.0, open_price + rng.uniform(-2.2, 2.6))
        high_price = max(open_price, close_price) + rng.uniform(0.2, 1.8)
        low_price = min(open_price, close_price) - rng.uniform(0.2, 1.8)

        records.append(
            {
                "date": session_date.isoformat(),
                "open": round(open_price, 2),
                "high": round(high_price, 2),
                "low": round(low_price, 2),
                "close": round(close_price, 2),
                "volume": rng.randint(1_800_000, 9_000_000),
            }
        )
        price = close_price

    return records


OHLCV = generate_ohlcv()

WATCHLIST_ROWS = [
    {"ticker": "FPT", "company": "FPT Corp", "price": 128.40, "change": 1.82, "volume": 5_482_100, "sector": "Công nghệ", "pe": 24.6, "rsi": 61.2},
    {"ticker": "VCB", "company": "Vietcombank", "price": 63.80, "change": -0.47, "volume": 2_103_400, "sector": "Ngân hàng", "pe": 15.1, "rsi": 48.5},
    {"ticker": "HPG", "company": "Hòa Phát", "price": 28.75, "change": 2.31, "volume": 32_452_700, "sector": "Thép", "pe": 13.8, "rsi": 66.4},
    {"ticker": "MWG", "company": "Thế Giới Di Động", "price": 67.20, "change": 0.75, "volume": 8_214_800, "sector": "Bán lẻ", "pe": 20.4, "rsi": 57.8},
    {"ticker": "VNM", "company": "Vinamilk", "price": 63.10, "change": -1.10, "volume": 4_621_300, "sector": "Tiêu dùng", "pe": 14.9, "rsi": 42.7},
    {"ticker": "SSI", "company": "SSI Securities", "price": 34.65, "change": 3.12, "volume": 41_654_900, "sector": "Chứng khoán", "pe": 17.2, "rsi": 70.1},
    {"ticker": "GAS", "company": "PV GAS", "price": 73.40, "change": -0.27, "volume": 1_240_500, "sector": "Năng lượng", "pe": 16.8, "rsi": 46.9},
    {"ticker": "VIC", "company": "Vingroup", "price": 47.90, "change": 1.05, "volume": 7_830_200, "sector": "Bất động sản", "pe": 31.5, "rsi": 54.2},
]

SCREENER_ROWS = [
    {**row, "ma20": round(row["price"] * rng.uniform(0.95, 1.04), 2), "ma50": round(row["price"] * rng.uniform(0.92, 1.07), 2)}
    for row in WATCHLIST_ROWS
]

PORTFOLIO_ROWS = [
    {"ticker": "FPT", "quantity": 2500, "avg_price": 112.30, "market_price": 128.40, "market_value": 321_000_000, "pnl": 40_250_000, "weight": 29.8},
    {"ticker": "VCB", "quantity": 3200, "avg_price": 58.20, "market_price": 63.80, "market_value": 204_160_000, "pnl": 17_920_000, "weight": 18.9},
    {"ticker": "HPG", "quantity": 7500, "avg_price": 25.10, "market_price": 28.75, "market_value": 215_625_000, "pnl": 27_375_000, "weight": 20.0},
    {"ticker": "MWG", "quantity": 2100, "avg_price": 61.70, "market_price": 67.20, "market_value": 141_120_000, "pnl": 11_550_000, "weight": 13.1},
    {"ticker": "VNM", "quantity": 3100, "avg_price": 66.40, "market_price": 63.10, "market_value": 195_610_000, "pnl": -10_230_000, "weight": 18.2},
]


# =============================================================================
# Formatting helpers
# =============================================================================

def format_compact(value: float) -> str:
    if abs(value) >= 1_000_000_000:
        return f"{value / 1_000_000_000:.1f}B"
    if abs(value) >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    if abs(value) >= 1_000:
        return f"{value / 1_000:.1f}K"
    return f"{value:,.0f}"


# =============================================================================
# Apache ECharts option builders
# =============================================================================

def performance_chart_options() -> dict[str, Any]:
    dates = [row["date"] for row in OHLCV]
    closes = [row["close"] for row in OHLCV]

    ma20: list[float] = []
    for index in range(len(closes)):
        window = closes[max(0, index - 19): index + 1]
        ma20.append(round(sum(window) / len(window), 2))

    return {
        "backgroundColor": "transparent",
        "animation": False,
        "tooltip": {"trigger": "axis"},
        "legend": {
            "top": 4,
            "right": 8,
            "data": ["VN-Index", "MA20"],
            "textStyle": {"color": THEME["muted"]},
        },
        "grid": {"left": 54, "right": 24, "top": 48, "bottom": 55},
        "xAxis": {
            "type": "category",
            "boundaryGap": False,
            "data": dates,
            "axisLine": {"lineStyle": {"color": THEME["border"]}},
            "axisLabel": {"color": THEME["muted"], "hideOverlap": True},
        },
        "yAxis": {
            "type": "value",
            "scale": True,
            "axisLabel": {"color": THEME["muted"]},
            "splitLine": {"lineStyle": {"color": THEME["border"], "opacity": 0.45}},
        },
        "dataZoom": [
            {"type": "inside", "start": 45, "end": 100},
            {
                "type": "slider",
                "height": 18,
                "bottom": 10,
                "start": 45,
                "end": 100,
                "borderColor": THEME["border"],
                "backgroundColor": THEME["surface_alt"],
            },
        ],
        "series": [
            {
                "name": "VN-Index",
                "type": "line",
                "data": closes,
                "showSymbol": False,
                "smooth": True,
                "lineStyle": {"width": 2, "color": THEME["primary"]},
                "areaStyle": {"opacity": 0.08, "color": THEME["primary"]},
            },
            {
                "name": "MA20",
                "type": "line",
                "data": ma20,
                "showSymbol": False,
                "lineStyle": {"width": 1.5, "color": THEME["warning"]},
            },
        ],
    }


def candlestick_chart_options() -> dict[str, Any]:
    dates = [row["date"] for row in OHLCV]
    candle_data = [
        [row["open"], row["close"], row["low"], row["high"]]
        for row in OHLCV
    ]

    return {
        "backgroundColor": "transparent",
        "animation": False,
        "tooltip": {"trigger": "axis", "axisPointer": {"type": "cross"}},
        "grid": {"left": 54, "right": 24, "top": 26, "bottom": 58},
        "xAxis": {
            "type": "category",
            "data": dates,
            "boundaryGap": True,
            "axisLine": {"lineStyle": {"color": THEME["border"]}},
            "axisLabel": {"color": THEME["muted"], "hideOverlap": True},
        },
        "yAxis": {
            "type": "value",
            "scale": True,
            "axisLabel": {"color": THEME["muted"]},
            "splitLine": {"lineStyle": {"color": THEME["border"], "opacity": 0.45}},
        },
        "dataZoom": [
            {"type": "inside", "start": 55, "end": 100},
            {
                "type": "slider",
                "height": 18,
                "bottom": 10,
                "start": 55,
                "end": 100,
                "borderColor": THEME["border"],
                "backgroundColor": THEME["surface_alt"],
            },
        ],
        "series": [
            {
                "name": "VN-Index",
                "type": "candlestick",
                "data": candle_data,
                "itemStyle": {
                    "color": THEME["positive"],
                    "color0": THEME["negative"],
                    "borderColor": THEME["positive"],
                    "borderColor0": THEME["negative"],
                },
            }
        ],
    }


def sector_chart_options() -> dict[str, Any]:
    sectors = ["Công nghệ", "Chứng khoán", "Thép", "Ngân hàng", "Bán lẻ", "Năng lượng"]
    performance = [3.4, 2.8, 1.9, 0.7, -0.4, -1.1]

    return {
        "backgroundColor": "transparent",
        "grid": {"left": 96, "right": 32, "top": 20, "bottom": 28},
        "xAxis": {
            "type": "value",
            "axisLabel": {"color": THEME["muted"], "formatter": "{value}%"},
            "splitLine": {"lineStyle": {"color": THEME["border"], "opacity": 0.45}},
        },
        "yAxis": {
            "type": "category",
            "data": sectors,
            "axisLabel": {"color": THEME["muted"]},
            "axisLine": {"show": False},
            "axisTick": {"show": False},
        },
        "series": [
            {
                "type": "bar",
                "barWidth": 18,
                "data": [
                    {
                        "value": value,
                        "itemStyle": {
                            "color": THEME["positive"] if value >= 0 else THEME["negative"],
                            "borderRadius": 5,
                        },
                    }
                    for value in performance
                ],
                "label": {
                    "show": True,
                    "position": "right",
                    "formatter": "{c}%",
                    "color": THEME["text"],
                },
            }
        ],
    }


def breadth_chart_options() -> dict[str, Any]:
    labels = ["Trên MA20", "Trên MA50", "Trên MA100", "Trên MA200"]
    values = [68, 61, 54, 47]

    return {
        "backgroundColor": "transparent",
        "grid": {"left": 48, "right": 20, "top": 25, "bottom": 44},
        "xAxis": {
            "type": "category",
            "data": labels,
            "axisLabel": {"color": THEME["muted"], "interval": 0},
            "axisLine": {"lineStyle": {"color": THEME["border"]}},
        },
        "yAxis": {
            "type": "value",
            "max": 100,
            "axisLabel": {"color": THEME["muted"], "formatter": "{value}%"},
            "splitLine": {"lineStyle": {"color": THEME["border"], "opacity": 0.45}},
        },
        "series": [
            {
                "type": "bar",
                "barWidth": "42%",
                "data": values,
                "itemStyle": {
                    "color": THEME["primary"],
                    "borderRadius": [6, 6, 0, 0],
                },
                "label": {
                    "show": True,
                    "position": "top",
                    "formatter": "{c}%",
                    "color": THEME["text"],
                },
            }
        ],
    }


def allocation_chart_options() -> dict[str, Any]:
    return {
        "backgroundColor": "transparent",
        "tooltip": {"trigger": "item", "formatter": "{b}: {c}%"},
        "legend": {
            "bottom": 0,
            "textStyle": {"color": THEME["muted"]},
        },
        "series": [
            {
                "type": "pie",
                "radius": ["52%", "76%"],
                "center": ["50%", "43%"],
                "label": {"show": False},
                "data": [
                    {"name": "Công nghệ", "value": 29.8},
                    {"name": "Ngân hàng", "value": 18.9},
                    {"name": "Thép", "value": 20.0},
                    {"name": "Bán lẻ", "value": 13.1},
                    {"name": "Tiêu dùng", "value": 18.2},
                ],
            }
        ],
    }


# =============================================================================
# Reusable UI components
# =============================================================================




def card_classes(extra: str = "") -> str:
    return (
        "dashboard-card rounded-2xl border shadow-sm min-w-0 "
        f"bg-[{THEME['surface']}] border-[{THEME['border']}] {extra}"
    )


def metric_card(
    title: str,
    value: str,
    change: str,
    *,
    positive: bool,
    icon: str,
) -> None:
    change_color = THEME["positive"] if positive else THEME["negative"]
    trend_icon = "north_east" if positive else "south_east"

    with ui.card().classes(card_classes("metric-card p-4 hover:-translate-y-0.5 transition-transform")):
        with ui.row().classes("w-full items-start justify-between no-wrap gap-3"):
            with ui.column().classes("gap-1 min-w-0"):
                ui.label(title).classes(f"text-xs uppercase tracking-wider text-[{THEME['muted']}]")
                ui.label(value).classes(f"text-xl xl:text-2xl font-bold text-[{THEME['text']}] truncate")
                with ui.row().classes("items-center gap-1 no-wrap"):
                    ui.icon(trend_icon).classes(f"text-sm text-[{change_color}]")
                    ui.label(change).classes(f"text-xs font-medium text-[{change_color}] truncate")
            ui.icon(icon).classes(
                f"text-xl text-[{THEME['primary']}] bg-[{THEME['surface_alt']}] "
                "rounded-xl p-2.5 shrink-0"
            )


def section_title(title: str, subtitle: str | None = None) -> None:
    with ui.column().classes("gap-0 min-w-0"):
        ui.label(title).classes("text-base md:text-lg font-semibold truncate")
        if subtitle:
            ui.label(subtitle).classes(f"text-xs md:text-sm text-[{THEME['muted']}] truncate")


def card_header(
    title: str,
    subtitle: str | None = None,
    *,
    icon: str | None = None,
) -> None:
    with ui.row().classes("w-full items-center justify-between gap-3 no-wrap"):
        with ui.row().classes("items-center gap-3 min-w-0 no-wrap"):
            if icon:
                ui.icon(icon).classes(
                    f"text-lg text-[{THEME['primary']}] bg-[{THEME['surface_alt']}] rounded-lg p-2"
                )
            section_title(title, subtitle)


def create_watchlist_grid() -> ui.aggrid:
    options = {
        "defaultColDef": {"sortable": True, "resizable": True},
        "columnDefs": [
            {"headerName": "Mã", "field": "ticker", "pinned": "left", "width": 82},
            {"headerName": "Giá", "field": "price", "width": 92,
             ":valueFormatter": "params => params.value.toLocaleString('vi-VN', {minimumFractionDigits: 2})"},
            {"headerName": "%", "field": "change", "width": 88,
             ":valueFormatter": "params => `${params.value > 0 ? '+' : ''}${params.value.toFixed(2)}%`",
             ":cellStyle": (
                 f"params => params.value >= 0 ? {{color: '{THEME['positive']}', fontWeight: 700}} "
                 f": {{color: '{THEME['negative']}', fontWeight: 700}}"
             )},
        ],
        "rowData": WATCHLIST_ROWS,
        "rowSelection": {"mode": "singleRow"},
        "animateRows": True,
        "headerHeight": 36,
        "rowHeight": 38,
    }
    return ui.aggrid(options, theme="quartz", auto_size_columns=False).classes("w-full h-[350px]")


def create_portfolio_grid() -> ui.aggrid:
    options = {
        "defaultColDef": {"sortable": True, "filter": True, "resizable": True},
        "columnDefs": [
            {"headerName": "Mã", "field": "ticker", "pinned": "left", "width": 90},
            {"headerName": "Khối lượng", "field": "quantity", "width": 120,
             ":valueFormatter": "params => params.value.toLocaleString('vi-VN')"},
            {"headerName": "Giá vốn", "field": "avg_price", "width": 110},
            {"headerName": "Giá thị trường", "field": "market_price", "width": 135},
            {"headerName": "Giá trị", "field": "market_value", "minWidth": 145,
             ":valueFormatter": "params => params.value.toLocaleString('vi-VN')"},
            {"headerName": "Lãi/Lỗ", "field": "pnl", "minWidth": 135,
             ":valueFormatter": "params => params.value.toLocaleString('vi-VN')",
             ":cellStyle": (
                 f"params => params.value >= 0 ? {{color: '{THEME['positive']}', fontWeight: 700}} "
                 f": {{color: '{THEME['negative']}', fontWeight: 700}}"
             )},
            {"headerName": "Tỷ trọng", "field": "weight", "width": 110,
             ":valueFormatter": "params => `${params.value.toFixed(1)}%`"},
        ],
        "rowData": PORTFOLIO_ROWS,
        "animateRows": True,
    }
    return ui.aggrid(options, theme="quartz", auto_size_columns=False).classes("w-full h-[390px]")



def get_investor_cashflow(
    start_date: str | None = None,
    timeframe: str = "daily",
) -> pd.DataFrame:
    """Lấy chuỗi thời gian mua/bán ròng theo nhóm nhà đầu tư."""
    normalized = str(timeframe).strip().lower()
    aliases = {
        "daily": "daily", "day": "daily", "1d": "daily",
        "weekly": "weekly", "week": "weekly", "1w": "weekly",
        "monthly": "monthly", "month": "monthly", "1m": "monthly",
    }
    if normalized not in aliases:
        raise ValueError("timeframe phải là daily, weekly hoặc monthly")
    normalized = aliases[normalized]

    conditions: list[str] = []
    parameters: list[object] = []
    if start_date:
        conditions.append('"Date" >= CAST(? AS DATE)')
        parameters.append(start_date)

    where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""
    sql = f"""
        SELECT
            "Date" AS time,
            SUM(COALESCE("AC_NetVal", 0)) / 1000000000.0 AS institutional,
            SUM(COALESCE("CC_NetVal", 0)) / 1000000000.0 AS individual,
            SUM(COALESCE("NN_NetVal", 0)) / 1000000000.0 AS foreign_flow,
            SUM(COALESCE("TD_NetVal", 0)) / 1000000000.0 AS proprietary
        FROM "CherryMon"."main"."vw_ACCCNNTD_Price"
        {where_clause}
        GROUP BY "Date"
        ORDER BY "Date"
    """

    with DuckDBManager(read_only=True) as connection:
        df = connection.execute(sql, parameters).df()
    columns = ["time", "institutional", "individual", "foreign_flow", "proprietary"]
    if df.empty:
        return pd.DataFrame(columns=columns)

    df["time"] = pd.to_datetime(df["time"], errors="coerce")
    numeric_columns = columns[1:]
    for column in numeric_columns:
        df[column] = pd.to_numeric(df[column], errors="coerce").fillna(0.0)

    df = (
        df.dropna(subset=["time"])
        .sort_values("time")
        .drop_duplicates(subset=["time"], keep="last")
        .reset_index(drop=True)
    )

    if normalized != "daily":
        frequency = "W-FRI" if normalized == "weekly" else "ME"
        df = (
            df.set_index("time")[numeric_columns]
            .resample(frequency)
            .sum(min_count=1)
            .fillna(0.0)
            .reset_index()
        )

    return df[columns]


def get_cashflow_cumulative_summary(
    timeframe: str = "daily",
    start_date: str | None = None,
) -> dict[str, float]:
    """Tính dòng tiền lũy kế trên toàn bộ dữ liệu đang được lọc."""
    df = get_investor_cashflow(start_date=start_date, timeframe=timeframe)
    columns = {
        "institutional": "Tổ chức",
        "individual": "Cá nhân",
        "foreign_flow": "Nước ngoài",
        "proprietary": "Tự doanh",
    }
    if df.empty:
        return {label: 0.0 for label in columns.values()}
    return {
        label: float(df[column].sum())
        for column, label in columns.items()
    }


def build_investor_cashflow_chart(
    timeframe: str = "daily",
    start_date: str | None = None,
):
    """Tạo lightweight chart cho dòng tiền theo nhóm nhà đầu tư."""
    df = get_investor_cashflow(
        start_date=start_date,
        timeframe=timeframe,
    )
    if df.empty:
        return None, df

    chart_df = df.copy()
    chart_df["time"] = (
        pd.to_datetime(chart_df["time"], errors="coerce")
        .dt.strftime("%Y-%m-%d")
    )
    chart_df = chart_df.dropna(subset=["time"]).reset_index(drop=True)
    if chart_df.empty:
        return None, chart_df

    chart = chart_plot.init_chart(
        height=500,
        inner_width=1,
        inner_height=1,
        background_color=THEME["surface"],
        text_color=THEME["text"],
        legend_visible=True,
    )

    series_config = (
        ("Tổ chức", "institutional", "#38bdf8"),
        ("Cá nhân", "individual", "#f59e0b"),
        ("Nước ngoài", "foreign_flow", "#22c55e"),
        ("Tự doanh", "proprietary", "#ef4444"),
    )

    created_lines = []
    for label, column, color in series_config:
        line = chart_plot.add_line(
            chart=chart,
            data=chart_df[["time", column]],
            name=column,
            label_name=label,
            color=color,
            width=2,
            price_line=False,
            price_label=False,
        )
        created_lines.append(line)

    # Đường mức 0 dùng price line thay vì một series riêng để không xuất hiện
    # trong legend. lineStyle=2 tương ứng nét đứt của Lightweight Charts.
    if created_lines:
        zero_anchor = created_lines[0]
        chart.run_script(
            f"""
            if ({zero_anchor.id} && {zero_anchor.id}.series) {{
                {zero_anchor.id}.series.createPriceLine({{
                    price: 0,
                    color: 'rgba(143, 163, 189, 0.24)',
                    lineWidth: 1,
                    lineStyle: 2,
                    axisLabelVisible: false,
                    title: ''
                }});
            }}
            """
        )

    normalized = str(timeframe).strip().lower()
    bar_spacing = {
        "daily": 6,
        "weekly": 10,
        "monthly": 16,
    }.get(normalized, 6)

    chart.run_script(
        f"""
        {chart.id}.chart.applyOptions({{
            layout: {{
                background: {{type: 'solid', color: '{THEME["surface"]}'}},
                textColor: '{THEME["muted"]}'
            }},
            grid: {{
                vertLines: {{color: 'rgba(38, 55, 80, 0.35)'}},
                horzLines: {{color: 'rgba(38, 55, 80, 0.50)'}}
            }},
            crosshair: {{
                vertLine: {{color: 'rgba(143, 163, 189, 0.55)', width: 1, style: 2}},
                horzLine: {{color: 'rgba(143, 163, 189, 0.35)', width: 1, style: 2}}
            }},
            rightPriceScale: {{
                borderColor: '{THEME["border"]}',
                scaleMargins: {{top: 0.12, bottom: 0.12}}
            }},
            timeScale: {{
                borderColor: '{THEME["border"]}',
                timeVisible: false,
                secondsVisible: false,
                barSpacing: {bar_spacing},
                rightOffset: 2,
                fixLeftEdge: true,
                fixRightEdge: true
            }}
        }});
        """
    )

    # Cài tooltip sau khi Lightweight Charts đã khởi tạo xong. Dùng cơ chế retry
    # vì script có thể được thực thi trước khi handler/series sẵn sàng trong iframe.
    series_meta_js = ",\n".join(
        f"{{series: {line.id}.series, label: {label!r}, color: {color!r}}}"
        for line, (label, _, color) in zip(created_lines, series_config)
    )

    chart.run_script(
        f"""
        (function installCashflowPointTooltip(attempt) {{
            attempt = attempt || 0;

            const handler = (typeof {chart.id} !== 'undefined') ? {chart.id} : null;
            const seriesReady = [
                {series_meta_js}
            ].every(function(item) {{
                return item.series && typeof item.series.applyOptions === 'function';
            }});

            if (!handler || !handler.chart || !handler.wrapper || !seriesReady) {{
                if (attempt < 80) {{
                    setTimeout(function() {{
                        installCashflowPointTooltip(attempt + 1);
                    }}, 50);
                }}
                return;
            }}

            if (handler.__cashflowPointTooltipInstalled) return;
            handler.__cashflowPointTooltipInstalled = true;

            console.info('[CherryStock] cashflow tooltip installed', {{
                chartId: {chart.id!r},
                attempt: attempt
            }});

            const seriesMeta = [
                {series_meta_js}
            ];

            seriesMeta.forEach(function(item) {{
                item.series.applyOptions({{
                    crosshairMarkerVisible: true,
                    crosshairMarkerRadius: 5,
                    crosshairMarkerBorderWidth: 2,
                    crosshairMarkerBorderColor: item.color,
                    crosshairMarkerBackgroundColor: '#FFFFFF'
                }});
            }});

            handler.wrapper.style.position = 'relative';

            let tooltip = handler.wrapper.querySelector('.cashflow-point-tooltip');
            if (!tooltip) {{
                tooltip = document.createElement('div');
                tooltip.className = 'cashflow-point-tooltip';
                Object.assign(tooltip.style, {{
                    position: 'absolute',
                    top: '48px',
                    right: '14px',
                    zIndex: '99999',
                    display: 'none',
                    minWidth: '210px',
                    padding: '10px 12px',
                    border: '1px solid rgba(143, 163, 189, 0.42)',
                    borderRadius: '8px',
                    background: 'rgba(7, 17, 31, 0.97)',
                    boxShadow: '0 8px 28px rgba(0, 0, 0, 0.38)',
                    color: '#E5EDF7',
                    fontFamily: 'Segoe UI, Arial, sans-serif',
                    fontSize: '12px',
                    lineHeight: '1.4',
                    pointerEvents: 'none'
                }});
                handler.wrapper.appendChild(tooltip);
            }}

            function formatDateOnly(time) {{
                if (!time) return '';
                if (typeof time === 'string') {{
                    const parts = time.split('-');
                    return parts.length === 3
                        ? parts[2] + '/' + parts[1] + '/' + parts[0]
                        : time;
                }}
                if (typeof time === 'object' && time.year && time.month && time.day) {{
                    return String(time.day).padStart(2, '0') + '/'
                        + String(time.month).padStart(2, '0') + '/'
                        + String(time.year);
                }}
                if (typeof time === 'number') {{
                    const date = new Date(time * 1000);
                    return String(date.getUTCDate()).padStart(2, '0') + '/'
                        + String(date.getUTCMonth() + 1).padStart(2, '0') + '/'
                        + String(date.getUTCFullYear());
                }}
                return String(time);
            }}

            function readValue(param, series) {{
                let data = null;
                if (param.seriesData && typeof param.seriesData.get === 'function') {{
                    data = param.seriesData.get(series);
                }}
                if ((data === null || data === undefined)
                    && param.seriesPrices
                    && typeof param.seriesPrices.get === 'function') {{
                    data = param.seriesPrices.get(series);
                }}
                if (typeof data === 'number') return data;
                if (data && Number.isFinite(data.value)) return data.value;
                if (data && Number.isFinite(data.close)) return data.close;
                return null;
            }}

            function formatValue(value) {{
                if (!Number.isFinite(value)) return '—';
                const sign = value > 0 ? '+' : '';
                return sign + value.toLocaleString('vi-VN', {{
                    minimumFractionDigits: 1,
                    maximumFractionDigits: 1
                }}) + ' tỷ';
            }}

            handler.chart.subscribeCrosshairMove(function(param) {{
                if (!param || !param.time || !param.point) {{
                    tooltip.style.display = 'none';
                    return;
                }}

                const chartWidth = handler.wrapper.clientWidth;
                const chartHeight = handler.wrapper.clientHeight;
                if (param.point.x < 0 || param.point.y < 0
                    || param.point.x > chartWidth || param.point.y > chartHeight) {{
                    tooltip.style.display = 'none';
                    return;
                }}

                let hasAnyValue = false;
                const rows = seriesMeta.map(function(item) {{
                    const value = readValue(param, item.series);
                    if (Number.isFinite(value)) hasAnyValue = true;
                    const valueColor = !Number.isFinite(value)
                        ? '#8FA3BD'
                        : (value > 0 ? '#22C55E' : (value < 0 ? '#EF4444' : '#E5EDF7'));

                    return '<div style="display:flex;align-items:center;justify-content:space-between;'
                        + 'gap:18px;margin-top:5px;">'
                        + '<span style="display:inline-flex;align-items:center;gap:7px;color:#B7C4D6;">'
                        + '<span style="width:8px;height:8px;border-radius:50%;background:'
                        + item.color + ';display:inline-block;"></span>'
                        + item.label + '</span>'
                        + '<strong style="color:' + valueColor + ';font-weight:700;">'
                        + formatValue(value) + '</strong></div>';
                }}).join('');

                if (!hasAnyValue) {{
                    tooltip.style.display = 'none';
                    return;
                }}

                tooltip.innerHTML = '<div style="font-weight:700;color:#FFFFFF;'
                    + 'padding-bottom:5px;border-bottom:1px solid rgba(143,163,189,0.20);">'
                    + formatDateOnly(param.time) + '</div>' + rows;
                tooltip.style.display = 'block';
            }});
        }})(0);
        """
    )

    first_date = str(chart_df["time"].iloc[0])
    last_date = str(chart_df["time"].iloc[-1])
    chart_plot.load_chart(
        chart=chart,
        precision=1,
        visible_range=(first_date, last_date),
    )
    return chart, df

# =============================================================================
# Tab contents
# =============================================================================

def overview_tab_content() -> None:
    symbol_sources = {
        "remaining_vnindex": {"symbol": "VNINDEX_NOT_VIN", "source": "custom", "color": "#A0AEC0", "label_name": "Remaining VNINDEX", "target": "main"},
        "vnindex": {"symbol": "VNINDEX", "source": "index", "color": "#03FD10", "label_name": "VNINDEX", "target": "main"},
        "btc": {"symbol": "BTC-USD", "source": "other", "color": "#F7931A", "label_name": "BTC-USD", "target": "main"},
        "spx": {"symbol": "^SPX", "source": "other", "color": "#3182CE", "label_name": "SPX", "target": "main"},
        "ndx": {"symbol": "^NDX", "source": "other", "color": "#00B5D8", "label_name": "NDX", "target": "main"},
        "gcz": {"symbol": "^GCZ", "source": "other", "color": "#ECC94B", "label_name": "Gold", "target": "main"},
        "lcoz": {"symbol": "^LCOZ", "source": "other", "color": "#E53E3E", "label_name": "Oil", "target": "main"},
        "dxy": {"symbol": "DX-Y.NYB", "source": "other", "color": "#A0AEC0", "label_name": "DXY", "target": "sub"},
        "VND=X": {"symbol": "VND=X", "source": "other", "color": "#FFAA00", "label_name": "USD/VND", "target": "sub"},
    }

    with ui.element("div").classes("grid grid-cols-2 lg:grid-cols-5 gap-3 w-full"):
        metric_card("VN-Index", "1,286.42", "+1.18% hôm nay", positive=True, icon="show_chart")
        metric_card("GTGD HOSE", "18.6 nghìn tỷ", "+12.4% so với TB20", positive=True, icon="payments")
        metric_card("Độ rộng", "268 / 151", "Nghiêng về bên mua", positive=True, icon="compare_arrows")
        metric_card("Khối ngoại", "-642 tỷ", "Bán ròng", positive=False, icon="public")
        metric_card("Tự doanh", "-1 tỷ", "Bán ròng", positive=False, icon="account_balance")

    with ui.element("div").classes("grid grid-cols-1 xl:grid-cols-12 gap-4 w-full"):
        with ui.card().classes(card_classes("p-4 xl:col-span-9")):
            with ui.row().classes("w-full items-center justify-between gap-3"):
                card_header("Intermarket", "VN-Index so với tài sản toàn cầu", icon="language")
                intermarket_timeframe = ui.toggle(TIMEFRAME_OPTIONS, value="daily").props(
                    "dense unelevated no-caps toggle-color=primary"
                ).classes("timeframe-toggle")
            intermarket_container = ui.html("", sanitize=False).classes("w-full min-w-0 mt-2")

            def refresh_intermarket() -> None:
                chart = chart_plot.draw_comparision_main_sub(
                    start_date=CHART_START_DATE,
                    symbol_sources=symbol_sources,
                    timeframe=str(intermarket_timeframe.value or "daily"),
                )
                intermarket_container.set_content(
                    chart_plot.build_chart_iframe_html(chart, height=IFRAME_HEIGHT)
                )

            intermarket_timeframe.on_value_change(lambda _: refresh_intermarket())
            refresh_intermarket()

        with ui.card().classes(card_classes("p-4 xl:col-span-3")):
            card_header("Watchlist", "Danh sách theo dõi", icon="star")
            with ui.row().classes("w-full gap-2 mt-3"):
                ui.input(placeholder="Tìm mã...").props("dense outlined clearable").classes("flex-1")
                ui.button(icon="add").props("round dense unelevated").tooltip("Thêm mã")
            create_watchlist_grid()

        with ui.card().classes(card_classes("p-4 xl:col-span-8")):
            with ui.row().classes("w-full items-center justify-between gap-3"):
                card_header("Độ rộng thị trường", "Tỷ lệ cổ phiếu trên MA20/50/100/200", icon="insights")
                breadth_timeframe = ui.toggle(TIMEFRAME_OPTIONS, value="daily").props(
                    "dense unelevated no-caps toggle-color=primary"
                ).classes("timeframe-toggle")
            breadth_container = ui.html("", sanitize=False).classes("w-full min-w-0 mt-2")

            def refresh_market_breadth() -> None:
                chart = chart_plot.draw_ticker_above_MA(
                    start_date=CHART_START_DATE,
                    timeframe=str(breadth_timeframe.value or "daily"),
                )
                breadth_container.set_content(
                    chart_plot.build_chart_iframe_html(chart, height=IFRAME_HEIGHT)
                )

            breadth_timeframe.on_value_change(lambda _: refresh_market_breadth())
            refresh_market_breadth()

        with ui.card().classes(card_classes("p-4 xl:col-span-4")):
            card_header("Hiệu suất ngành", "Biến động trong phiên", icon="donut_large")
            ui.echart(sector_chart_options()).classes("w-full h-[430px]")

        with ui.card().classes(card_classes("p-4 xl:col-span-12")):
            with ui.row().classes("w-full items-center justify-between gap-3"):
                card_header(
                    "Dòng tiền nhà đầu tư",
                    "Chuỗi thời gian mua/bán ròng theo Ngày, Tuần và Tháng — đơn vị tỷ đồng",
                    icon="account_balance",
                )
                cashflow_timeframe = ui.toggle(
                    TIMEFRAME_OPTIONS,
                    value="daily",
                ).props(
                    "dense unelevated no-caps toggle-color=primary"
                ).classes("timeframe-toggle")

            cumulative_labels: dict[str, ui.label] = {}
            with ui.element("div").classes(
                "grid grid-cols-2 lg:grid-cols-4 gap-3 w-full mt-4"
            ):
                for investor_name, icon_name in (
                    ("Tổ chức", "corporate_fare"),
                    ("Cá nhân", "person"),
                    ("Nước ngoài", "public"),
                    ("Tự doanh", "account_balance"),
                ):
                    with ui.element("div").classes(
                        "rounded-xl border px-4 py-3 "
                        f"bg-[{THEME['surface_alt']}] border-[{THEME['border']}]"
                    ):
                        with ui.row().classes("items-center gap-2"):
                            ui.icon(icon_name).classes(f"text-[{THEME['primary']}]")
                            ui.label(investor_name).classes(
                                f"text-xs font-medium text-[{THEME['muted']}]"
                            )
                        cumulative_labels[investor_name] = ui.label("0 tỷ").classes(
                            "text-xl font-bold mt-2"
                        )
                        ui.label("Lũy kế theo khung đang chọn").classes(
                            f"text-[11px] text-[{THEME['muted']}]"
                        )

            cashflow_container = ui.html(
                "",
                sanitize=False,
            ).classes("w-full min-w-0 mt-2")

            def set_cumulative_labels(summary: dict[str, float]) -> None:
                for investor_name, value in summary.items():
                    label = cumulative_labels[investor_name]
                    sign = "+" if value > 0 else ""
                    label.set_text(f"{sign}{value:,.1f} tỷ")
                    label.classes(
                        remove=(
                            f"text-[{THEME['positive']}] "
                            f"text-[{THEME['negative']}] "
                            f"text-[{THEME['muted']}]"
                        )
                    )
                    if value > 0:
                        label.classes(f"text-[{THEME['positive']}]")
                    elif value < 0:
                        label.classes(f"text-[{THEME['negative']}]")
                    else:
                        label.classes(f"text-[{THEME['muted']}]")

            def summarize_cashflow(df: pd.DataFrame) -> dict[str, float]:
                mapping = {
                    "institutional": "Tổ chức",
                    "individual": "Cá nhân",
                    "foreign_flow": "Nước ngoài",
                    "proprietary": "Tự doanh",
                }
                if df.empty:
                    return {label: 0.0 for label in mapping.values()}
                return {
                    label: float(
                        pd.to_numeric(df[column], errors="coerce")
                        .fillna(0.0)
                        .sum()
                    )
                    for column, label in mapping.items()
                }

            def refresh_cashflow() -> None:
                selected_timeframe = str(
                    cashflow_timeframe.value or "daily"
                ).strip().lower()

                chart, filtered_df = build_investor_cashflow_chart(
                    timeframe=selected_timeframe,
                    start_date=CHART_START_DATE,
                )

                if chart is None:
                    cashflow_container.set_content(
                        '<div style="height:500px;display:flex;align-items:center;'
                        'justify-content:center;color:#8fa3bd;">'
                        'Không có dữ liệu dòng tiền</div>'
                    )
                else:
                    iframe_html = chart_plot.build_chart_iframe_html(
                        chart,
                        height=500,
                    )
                    # Nonce làm nội dung srcdoc khác nhau sau mỗi lần render,
                    # buộc NiceGUI thay iframe thay vì tái sử dụng DOM cũ.
                    render_nonce = time_ns()
                    cashflow_container.set_content(
                        f"<!-- cashflow-build:{render_nonce} -->{iframe_html}"
                    )

                set_cumulative_labels(summarize_cashflow(filtered_df))

            cashflow_timeframe.on_value_change(lambda _: refresh_cashflow())
            refresh_cashflow()


def market_tab_content() -> None:
    df = view_to_dataframe("vw_Ticker", condition="Status = 'Y'")
    with ui.card().classes(card_classes("p-4 w-full")):
        with ui.row().classes("w-full items-center justify-between gap-3 mb-3"):
            card_header("Stock Screener", "Lọc và so sánh cổ phiếu Việt Nam", icon="filter_alt")
            with ui.row().classes("items-center gap-2"):
                ui.button("Xuất Excel", icon="download").props("outline dense no-caps")
                ui.button("Lưu bộ lọc", icon="bookmark_add").props("unelevated dense no-caps")
        create_market_grid(
            df=df,
            filter_configs=NiceGUI_grid_market_tb.filter_configs,
            field_configs=NiceGUI_grid_market_tb.field_configs,
        )


def portfolio_tab_content() -> None:
    with ui.element("div").classes("grid grid-cols-2 lg:grid-cols-4 gap-3 w-full"):
        metric_card("Giá trị danh mục", "1.078 tỷ", "+86.9 triệu", positive=True, icon="account_balance_wallet")
        metric_card("Lãi/Lỗ hôm nay", "+14.2 triệu", "+1.34%", positive=True, icon="trending_up")
        metric_card("Tiền mặt", "146.5 triệu", "12.0% tài sản", positive=True, icon="savings")
        metric_card("Max Drawdown", "-8.42%", "Trong 12 tháng", positive=False, icon="waterfall_chart")

    with ui.element("div").classes("grid grid-cols-1 xl:grid-cols-12 gap-4 w-full"):
        with ui.card().classes(card_classes("p-4 xl:col-span-4")):
            card_header("Phân bổ danh mục", "Theo nhóm ngành", icon="pie_chart")
            ui.echart(allocation_chart_options()).classes("w-full h-[390px]")
        with ui.card().classes(card_classes("p-4 xl:col-span-8")):
            card_header("Vị thế đang nắm giữ", "Cập nhật theo giá thị trường", icon="table_chart")
            create_portfolio_grid()


# =============================================================================
# Page layout
# =============================================================================

def build_page() -> None:
    ui.colors(primary=THEME["primary"])
    ui.add_head_html('<meta name="viewport" content="width=device-width, initial-scale=1">')
    ui.add_css(f"""
        :root {{ --q-primary: {THEME['primary']}; }}
        body {{ background: {THEME['background']}; color: {THEME['text']}; }}
        .q-page, .q-layout, .nicegui-content {{ background: {THEME['background']}; }}
        .nicegui-content {{ padding: 0 !important; }}
        .dashboard-card {{ overflow: hidden; backdrop-filter: blur(12px); }}
        .dashboard-card:hover {{ border-color: #36506f; }}
        .metric-card {{ min-height: 112px; }}
        .q-tab {{ min-height: 46px; padding: 0 16px; }}
        .q-tab--active {{ background: {THEME['surface_alt']}; border-radius: 10px; }}
        .q-field--outlined .q-field__control:before {{ border-color: {THEME['border']}; }}
        .q-field--outlined:hover .q-field__control:before {{ border-color: #3c5878; }}
        .ag-root-wrapper {{ border-color: {THEME['border']} !important; border-radius: 12px !important; }}
        .timeframe-toggle .q-btn {{ min-width: 58px; }}
        .app-shell {{ max-width: 2200px; margin: 0 auto; }}
        @media (max-width: 700px) {{
            .metric-card {{ min-height: 104px; }}
            .timeframe-toggle .q-btn {{ min-width: 48px; padding-left: 8px; padding-right: 8px; }}
        }}
    """)

    with ui.left_drawer(value=False).props("width=260 breakpoint=1024").classes(
        f"bg-[{THEME['surface']}] border-r border-[{THEME['border']}] p-3"
    ) as drawer:
        with ui.row().classes("items-center gap-3 px-2 py-3"):
            ui.icon("candlestick_chart").classes(f"text-3xl text-[{THEME['primary']}]")
            with ui.column().classes("gap-0"):
                ui.label("CherryStock").classes("text-lg font-bold")
                ui.label("Financial Terminal").classes(f"text-xs text-[{THEME['muted']}]")
        ui.separator().classes(f"my-2 bg-[{THEME['border']}]")
        for label, icon in [
            ("Tổng quan", "dashboard"), ("Thị trường", "show_chart"),
            ("Screener", "filter_alt"), ("Danh mục", "account_balance_wallet"),
            ("Watchlist", "star"), ("Cảnh báo", "notifications_active")
        ]:
            ui.button(label, icon=icon).props("flat align=left no-caps").classes(
                "w-full justify-start rounded-xl py-2"
            )
        ui.space()
        ui.separator().classes(f"my-2 bg-[{THEME['border']}]")
        ui.button("Cài đặt", icon="settings").props("flat align=left no-caps").classes(
            "w-full justify-start rounded-xl"
        )

    with ui.header().classes(
        f"h-16 px-3 md:px-5 items-center justify-between bg-[{THEME['surface']}] "
        f"border-b border-[{THEME['border']}]"
    ):
        with ui.row().classes("items-center gap-2 md:gap-3 no-wrap"):
            ui.button(icon="menu", on_click=drawer.toggle).props("flat round dense")
            ui.label("CherryStock").classes("font-bold text-lg md:text-xl")
            ui.badge("LIVE", color="positive").props("outline").classes("hidden sm:flex")
        with ui.row().classes("items-center gap-2 no-wrap"):
            ui.input(placeholder="Tìm mã, công ty...").props(
                "dense outlined rounded debounce=300 clearable"
            ).classes("hidden md:flex w-64 xl:w-80")
            ui.button(icon="refresh", on_click=lambda: ui.notify("Đã làm mới dữ liệu")).props("flat round")
            ui.button(icon="notifications").props("flat round")
            ui.avatar("CS").classes(f"bg-[{THEME['primary']}] text-black font-bold")

    with ui.column().classes("app-shell w-full px-3 md:px-5 py-4 gap-4"):
        with ui.row().classes("w-full items-end justify-between gap-3"):
            with ui.column().classes("gap-0"):
                ui.label("Trung tâm thị trường").classes("text-xl md:text-2xl font-bold")
                ui.label("Theo dõi xu hướng, độ rộng và danh mục trong một màn hình").classes(
                    f"text-xs md:text-sm text-[{THEME['muted']}]"
                )
            ui.select(
                ["Phiên hiện tại", "1 tuần", "1 tháng", "3 tháng"],
                value="Phiên hiện tại",
            ).props("dense outlined options-dense").classes("hidden sm:flex w-40")

        with ui.tabs().classes(
            f"w-full rounded-xl p-1 bg-[{THEME['surface']}] border border-[{THEME['border']}]"
        ).props("align=left inline-label mobile-arrows outside-arrows") as tabs:
            ui.tab("overview", label="Tổng quan", icon="dashboard")
            ui.tab("market", label="Screener", icon="filter_alt")
            ui.tab("portfolio", label="Danh mục", icon="account_balance_wallet")

        with ui.tab_panels(tabs, value="overview").classes(
            "w-full bg-transparent p-0"
        ).props("animated keep-alive swipeable"):
            with ui.tab_panel("overview").classes("p-0 gap-4"):
                overview_tab_content()
            with ui.tab_panel("market").classes("p-0"):
                market_tab_content()
            with ui.tab_panel("portfolio").classes("p-0 gap-4"):
                portfolio_tab_content()


build_page()

ui.run(
    host="0.0.0.0",
    port=8081,
    title="CherryStock Financial Terminal",
    dark=True,
    reload=False,
)