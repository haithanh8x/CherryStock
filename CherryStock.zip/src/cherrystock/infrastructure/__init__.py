"""Infrastructure layer for CherryStock."""
