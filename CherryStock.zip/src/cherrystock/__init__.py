"""CherryStock package."""
