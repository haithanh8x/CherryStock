"""Application layer for CherryStock."""
